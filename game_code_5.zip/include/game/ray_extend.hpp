#include <game/common.hpp>

#ifndef GAME_RAY_EXTEND_HPP_HEADER_INCLUDE_GUARD
#define GAME_RAY_EXTEND_HPP_HEADER_INCLUDE_GUARD
namespace Game::RayExtend
{
	inline ::Vector3 operator+(::Vector3 left, float right) {
		return Vector3AddValue(left, right);
	}

	inline ::Vector3 operator+(::Vector3 left, ::Vector3 right) {
		return Vector3Add(left, right);
	}
	inline ::Vector3 operator-(::Vector3 left, ::Vector3 right) {
		return Vector3Add(left, Vector3Negate(right));
	}

	inline ::Vector3 operator*(::Vector3 left, ::Vector3 right) {
		return Vector3Multiply(left, right);
	}

	inline ::Vector3 operator*(::Vector3 left, float right) {
		return ::Vector3{ left.x * right, left.y * right, left.z * right };
	}

	inline ::Vector3 operator/(::Vector3 left, ::Vector3 right) {
		return Vector3Divide(left, right);
	}

	inline ::Vector3 operator/(::Vector3 left, float right) {
		return ::Vector3{ left.x / right, left.y / right, left.z / right };
	}
}
#endif // GAME_RAY_EXTEND_HPP_HEADER_INCLUDE_GUARD
